﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace S8_53_ConsoleUSB
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleUSB console = new ConsoleUSB();
            console.Run();
        }
    }
}
