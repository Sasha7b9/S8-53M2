#pragma once


void sprintf(char *, ...);
