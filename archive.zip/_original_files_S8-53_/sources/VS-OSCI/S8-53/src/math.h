#pragma once


float fabs(float);
float sin(float);
float cos(float);
float fabsf(float);
float sqrt(float);
float log10(float);
