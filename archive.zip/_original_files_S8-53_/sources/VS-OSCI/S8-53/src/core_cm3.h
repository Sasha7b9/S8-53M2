#pragma once


#define uint32_t unsigned int
#define int32_t signed int
#define uint8_t unsigned char
#define int8_t signed char
#define uint16_t unsigned short
#define int16_t signed short
#define uint64_t unsigned long long
#define __IO volatile
#define uintptr_t uint32_t *


#define NVIC_SetPriority(x, y)
