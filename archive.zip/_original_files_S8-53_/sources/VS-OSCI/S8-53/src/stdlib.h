#pragma once


void *malloc(int);
void free(void *);
#define RAND_MAX 65535
int rand();
