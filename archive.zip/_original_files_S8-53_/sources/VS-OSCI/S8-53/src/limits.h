#pragma once


#define INT_MAX   0x7fffffff
#define SHRT_MAX  0x7fff
