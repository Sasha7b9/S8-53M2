#pragma once
#include "defines.h"


void Display_Init(void);

void Display_Update(void);

void Display_Update1(void);

bool Display_IsRun(void);
