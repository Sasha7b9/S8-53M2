#include "defines.h"

void HardwareErrorHandler(const char *file, const char *function, int line)
{
    while (true)
    {
    };
};
