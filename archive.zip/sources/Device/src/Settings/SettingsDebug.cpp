#include "Settings.h"
#include "SettingsDebug.h"

int sDebug_GetSizeFontForConsole()
{
    return SIZE_FONT_CONSOLE ? 8 : 5;
}

