#include "defines.h"


void HardwareErrorHandler(const char *, const char *, int)
{
    while(true)
    {
    }; 
};
