// 2022/02/11 17:49:33 (c) Aleksandr Shevchenko e-mail : Sasha7b9@tut.by
#pragma once


class ADConverter
{
public:
    static void Init();
    static uint16 GetValue();
};
