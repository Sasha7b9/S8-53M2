// 2022/02/11 17:45:48 (c) Aleksandr Shevchenko e-mail : Sasha7b9@tut.by
#pragma once

void WelcomeScreen_Init();
void WelcomeScreen_Update();

bool WelcomeScreen_Run();
