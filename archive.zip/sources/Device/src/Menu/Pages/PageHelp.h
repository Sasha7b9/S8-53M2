#pragma once



class PageHelp
{
public:
    static void *GetPointer();
};
