#pragma once



class PageService
{
public:

    class Math
    {
    public:

        class Function
        {
        public:
            static void *GetPointer();
        };

        class FFT
        {
        public:

            class Cursors
            {
            public:
                static void *GetPointer();
            };
        };
    };

    class Information
    {
    public:

        static void *GetPointer();
    };
};
