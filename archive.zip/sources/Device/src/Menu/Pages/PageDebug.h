#pragma once


class PageDebug
{
public:
    class SerialNumber
    {
    public:
        static void *GetPointer();
    };
};
