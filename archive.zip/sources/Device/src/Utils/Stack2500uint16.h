/// @file

#pragma once

/*
void Stack_AddValue(uint16 value);
void Stack_MinMaxLast(int number, uint16 *min, uint16 *max);
*/
